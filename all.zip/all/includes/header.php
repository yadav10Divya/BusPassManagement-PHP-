<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      
.middle{
    width:58%;
    height:40%;
    margin-left:20%;
    margin-top:10%;
    background-color:black;
    padding:5px;
    text-align:center;
}
.animate-charcter
{
   text-transform: uppercase;

  background-image: 
    linear-gradient( #ffffff 10%, #9C27B0 29%, #ff1361 67%, #FFEB3B 100% );

  background-size: auto auto;
  background-clip: border-box;
  background-size: 200% auto;
  color: #fff;
  background-clip: text;
  text-fill-color: white;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: textclip 2s linear infinite;
  display: inline-block;
  font-size: 90px;
}

    </style>
</head>
<body>
    
</body>
</html>

<div class="top-nav w3-agiletop">
                <div class="container">
                    <div class="navbar-header w3llogo">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>  
                        <h1><a href="index.php" >Bus Pass Management System</a></h1> 
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <div class="w3menu navbar-right">
                            <ul class="nav navbar" style="color: black;">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About</a></li> 
                                                             
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="user/user.php">User Login</a></li>
                                <!-- <li><a href="download-pass.php">View Pass</a></li> -->
                                <li><a href="admin/index.php">Admin Login</a></li>
                            </ul>
                        </div> 
                        <div class="clearfix"> </div>
                    
                    </div>
                </div>  
            </div>
            <div class="middle">
            <div class="">
      <h3 class="animate-charcter">Apply For Pass Here</h3>
    </div>
           
            </div>