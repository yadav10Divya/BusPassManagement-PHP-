<?php
session_start();
error_reporting(0);

include('includes/dbconnection.php');
include('dbConfig.php');
    if(isset($_POST['submit']))
  {

$fname=$_POST['fullname'];
$cnum=$_POST['cnumber'];
$email=$_POST['email'];
$cat=$_POST['bus_name'];
$source=$_POST['source'];
$des=$_POST['destination'];
$fdate=$_POST['fromdate'];
$tdate=$_POST['todate'];
$cost=$_POST['cost'];
$passnum=mt_rand(100000000, 999999999);
$propic=$_FILES["propic"]["name"];
$extension = substr($propic,strlen($propic)-4,strlen($propic));
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Profile Pics has Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{

$propic=md5($propic).time().$extension;
 move_uploaded_file($_FILES["propic"]["tmp_name"],"images/".$propic);
$sql="insert into tblpass(PassNumber,FullName,ProfileImage,ContactNumber,Email,Category,Source,Destination,FromDate,ToDate,Cost)values(:passnum,:fname,:propic,:cnum,:email,:cat,:source,:des,:fdate,:tdate,:cost)";
$query=$dbh->prepare($sql);
$query->bindParam(':passnum',$passnum,PDO::PARAM_STR);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':cnum',$cnum,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);

$query->bindParam(':cat',$cat,PDO::PARAM_STR);
$query->bindParam(':source',$source,PDO::PARAM_STR);
$query->bindParam(':des',$des,PDO::PARAM_STR);
$query->bindParam(':fdate',$fdate,PDO::PARAM_STR);
$query->bindParam(':tdate',$tdate,PDO::PARAM_STR);
$query->bindParam(':cost',$cost,PDO::PARAM_STR);
$query->bindParam(':propic',$propic,PDO::PARAM_STR);

 $query->execute();
 $_SESSION['form_data'] = $_POST;
//    $LastInsertId=$dbh->lastInsertId();
   if ($query) {
    echo '<script>alert("Pass detail has been added.")</script>';
// echo "<script>window.location.href ='PayuMoney.php'</script>";
header('Location: PayUMoney.php?passnum="'.$passnum.'"');
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  

}
}
?>

<!DOCTYPE html>
<html>

<head>
    
    <title>Bus Pass Management System | Add Pass</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />



</head>

<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
      <?php include_once('includes/header.php');?>
        <!-- end navbar top -->

        <!-- navbar side -->
        <?php include_once('includes/sidebar.php');?>
        <!-- end navbar side -->
        <!--  page-wrapper -->
          <div id="page-wrapper">
            <div class="row">
                 <!-- page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Add Pass</h1>
                </div>
                <!--end page header -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                       
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form method="post" enctype="multipart/form-data" id="bus_book_form"> 
                                    
    <div class="form-group"> <label for="exampleInputEmail1">Full Name</label> <input type="text" name="fullname" value="" class="form-control" required='true'> </div>
    <div class="form-group"> <label for="exampleInputEmail1">Profile Image</label> <input type="file" name="propic" value="" class="form-control" required='true'> </div>
    <div class="form-group"> <label for="exampleInputEmail1">Contact Number</label> <input type="text" name="cnumber" value="" class="form-control" required='true' maxlength="10" pattern="[0-9]+"> </div>
    <div class="form-group"> <label for="exampleInputEmail1">Email Address</label> <input type="email" name="email" value="" class="form-control" required='true'> </div>
    
    <div class="form-group"> <label for="exampleInputEmail1">Bus Name:</label>
      <select id="bus_name" name="bus_name" type="text" class="form-control">
        <option value="">--Select Bus--</option>
    
        <?php 
$sql = "SELECT DISTINCT bus_name FROM buses";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
  echo '<option value="' . $row['bus_name'] . '">' . $row['bus_name'] . '</option>';
}
      
 ?>
     </select></div>
    
     <div class="form-group">
        <label for="source">Source</label>
        <select id="source" name="source" type="text" class="form-control">
        <option value="">--Select Source--</option>

    </select> </div>
     <div class="form-group">
         <label for="destination">Destination</label> 
         <select id="destination" name="destination" type="text" class="form-control">
         <option value="">--Select Destination--</option>

    </select></div>

    <div class="form-group"> 
    <label for="cost">Cost:</label>
      <input type="text" id="cost" name="cost" class="form-control" readonly>
        </div>    


<div class="form-group"> <label for="exampleInputEmail1">From Date</label> <input type="date" name="fromdate" value="" class="form-control" required='true'> </div>
<div class="form-group"> <label for="exampleInputEmail1">To Date</label> <input type="date" name="todate" value="" class="form-control" required='true'> </div>

<p style="padding-left: 450px"><button type="submit" class="btn btn-primary" name="submit" id="submit">Make Payment</button></form>


                                </div>
                                
                            </div>
                        </div>
                    </div>
                     <!-- End Form Elements -->
                </div>
            </div>
        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function() {
        // Event listener for bus name dropdown list
        $('#bus_name').on('change', function() {
          // Retrieve the selected bus name
          var bus_name = $(this).val();
          
          // Clear the source and destination dropdown lists
          $('#source').html('<option value="">--Select Source--</option>');
          $('#destination').html('<option value="">--Select Destination--</option>');
          
          // AJAX call to retrieve the list of sources that match the selected bus name
          $.ajax({
            type: 'POST',
            url: 'getSources.php',
            data: {bus_name: bus_name},
            success: function(data) {
              // Add the options to the source dropdown list
              $('#source').html('<option value="">--Select Source--</option>' + data);
            }
          });
        });
        
        // Event listener for source dropdown list
        $('#source').on('change', function() {
          // Retrieve the selected bus name and source
          var bus_name = $('#bus_name').val();
          var source = $(this).val();
          
          // Clear the destination dropdown list
          $('#destination').html('<option value="">--Select Destination--</option>');
          
          // AJAX call to retrieve the list of destinations that match the selected bus name and source
          $.ajax({
            type: 'POST',
            url: 'getDestinations.php',
            data: {bus_name: bus_name, source: source},
            success: function(data) {
              // Add the options to the destination dropdown list
              $('#destination').html('<option value="">--Select Destination--</option>' + data);
            }
          });
        });
        
        // Event listener for destination dropdown list
        $('#destination').on('change', function() {
          // Retrieve the selected bus name, source, and destination
          var bus_name = $('#bus_name').val();
          var source = $('#source').val();
          var destination = $(this).val();
          
          // AJAX call to retrieve the cost for the selected trip
          var cost = $('#bus_book_form').find('[name="cost"]');
          $.ajax({
            type: 'POST',
            url: 'getCost.php',
            data: {bus_name: bus_name, source: source, destination: destination},
            success: function(data) {
              // Set the cost input field to the retrieved value
              cost.val(data);
            }
          });
        });
      });
    </script>

    

</body>

</html>
