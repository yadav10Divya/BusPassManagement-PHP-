<?php
//Database configuration
$dbHost     = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName     = 'buspassdb';

//Create database connection
$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

//Check connection
if ($conn) {
    //echo "connected";
}
else{
    echo "error";
}
?>
