<?php
include('dbConfig.php');

if (isset($_POST['bus_name']) && isset($_POST['source']) && isset($_POST['destination'])) {
  $bus_name = $_POST['bus_name'];
  $source = $_POST['source'];
  $destination = $_POST['destination'];
  
  // Retrieve the cost for the selected trip
  $sql = "SELECT cost FROM buses WHERE bus_name='$bus_name' AND source='$source' AND destination='$destination'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  echo $row['cost'];
}
?>
