<?php
include('dbConfig.php');

// Get the selected bus name and source from the AJAX request
$bus_name = $_POST['bus_name'];
$source = $_POST['source'];

// Retrieve the list of destinations that match the selected bus name and source
$sql = "SELECT DISTINCT destination FROM buses WHERE bus_name = '$bus_name' AND source = '$source'";
$result = mysqli_query($conn, $sql);

// Create an option for each destination
$options = '';
while ($row = mysqli_fetch_assoc($result)) {
  $options .= "<option value='" . $row['destination'] . "'>" . $row['destination'] . "</option>";
}

// Return the options as an HTML string
echo $options;
?>