<?php
include('dbConfig.php');

// Get the selected bus name from the AJAX request
$bus_name = $_POST['bus_name'];

// Retrieve the list of sources that match the selected bus name
$sql = "SELECT DISTINCT source FROM buses WHERE bus_name = '$bus_name'";
$result = mysqli_query($conn, $sql);

// Create an option for each source
$options = '';
while ($row = mysqli_fetch_assoc($result)) {
  $options .= "<option value='" . $row['source'] . "'>" . $row['source'] . "</option>";
}

// Return the options as an HTML string
echo $options;
?>
