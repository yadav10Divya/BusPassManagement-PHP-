<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		.demo{
			width: 35%;
			height:55%;
			border:2px solid black;
			border-radius:10px;
			margin-left:25%;
			padding:20px;
			text-align:center;
		}
		body{

		
		text-align: center;
        padding: 40px 0;
        background: #EBF0F5;
      }
        h1 {
          color: #88B04B;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-weight: 900;
          font-size: 40px;
          margin-bottom: 10px;
        }
        p {
          color: #404F5E;
          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
          font-size:20px;
          margin: 0;
        }
      i {
        color: #9ABC66;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }
	</style>
</head>
<body>

<?php
session_start();
$status="success";
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$phone = $_POST["phone"];


$salt="";

// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
         
         
		 $hash = hash("sha512", $retHashSeq);
    
        // echo "<h3>Thank You. Your status is ". $status.".</h3>";
		
			//echo"<img alt="" class="bf jw jx c" width="220" height="220" loading="eager" role="presentation" src="https://miro.medium.com/v2/resize:fit:220/0*1KdBMHMD-oIVzoI7.gif">";
			?>
			<div class="card">
      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
        <i class="checkmark">✓</i>
      </div>
        <h1>Success</h1> 
        <p>Thank You<br/></p>
			<?php
			
			echo "<h3>Your Transaction ID for this transaction is ".$txnid.".</h4>";
          echo "<h3>We have received a payment of Rs. " . $amount . "</h4>";
		   }
		   ?>
		   </div>
		   <?php
		   

			$host = 'localhost';  

			$user = 'root';  

			$pass = '';  

			$dbname = 'buspassdb';  

			$conn = mysqli_connect($host, $user, $pass,$dbname);  

			if(!$conn){  

			  die('Could not connect: '.mysqli_connect_error());  
			}  

			//echo 'Connected successfully<br/>';  
			// echo $amount;
			// $sql = 'INSERT INTO paymentdetails(amount,name,email,mobile,productinfo) VALUES ("'.$amount.'","'.$firstname.'","'.$email.'","'.$phone.'","'.$productinfo.'")';  
			
			$sql= "UPDATE `tblpass` SET `status`='$status' WHERE ContactNumber='$phone' and Email ='$email'";
			if(mysqli_query($conn, $sql)){  

			// echo "Record inserted successfully";  

			}else{  

			echo "Could not insert record: ". mysqli_error($conn);  

			}  

			mysqli_close($conn); 	   
?>	
	
	</body>
</html>